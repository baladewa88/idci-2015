# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('idciapp', '0003_auto_20151216_0846'),
    ]

    operations = [
        migrations.RenameModel(
            old_name='ContactUs',
            new_name='AAContactUs',
        ),
    ]
